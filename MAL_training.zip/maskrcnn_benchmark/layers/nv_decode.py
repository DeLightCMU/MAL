from maskrcnn_benchmark import _C

nv_decode = _C.nv_decode

