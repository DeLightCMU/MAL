from maskrcnn_benchmark import _C

nv_nms = _C.nv_nms
# nms.__doc__ = """
# This function performs Non-maximum suppresion"""
